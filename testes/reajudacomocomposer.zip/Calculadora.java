package ws;

public class Calculadora {

	public static String soma(int parcela1, int parcela2){
		return String.valueOf(new Integer(parcela1) + new Integer(parcela2));
	}
	
	public static String subtracao(int minuendo, int subtraendo){
		return String.valueOf(new Integer(minuendo) - new Integer(subtraendo));
	}
}
